
#include <iostream>
#include <string>
using namespace std;

class Time
{
public:
	Time(int H, int M)
	{
		if (0 <= H && H <= 24) {
			Hour = H;
		}
		if (0 <= M && M <= 60) {
			Minute = M;
		}
	}
	Time(int H)
	{
		if (0 <= H && H <= 24) {
			Hour = H;
		}
		Minute = 0;
	}
	void SetTime(int H, int M);
	int compare(Time t);
	string TimeOfDay();
	int GetHour() { return Hour; }
	int GetMinute() { return Minute; }
private:
	int Hour;
	int Minute;
};
void Time::SetTime(int H, int M)
{
	if (H >= 0 && H <= 24) {
		Hour = H;
	}
	if (M >= 0 && M <= 60) {
		Minute = M;
	}
}

int Time::compare(Time t)
{
	if (Hour > t.Hour) {
		return 1;
	}
	else if (Hour == t.Hour)
	{
		if (Minute > t.Minute) {
			return 1;
		}
	}

	if (Hour == t.Hour && Minute == t.Minute) { return 0; }

	return -1;
}

string Time::TimeOfDay()
{
	if (0<Hour && Hour < 12) {
		return "morning";
	}
	if (Hour == 12) {
		return "noon";
	}
	if (12<Hour && Hour < 17) {
		return "afternoon";
	}
	if (17<=Hour && Hour < 20) {
		return "evening";
	}
	if (20<=Hour && Hour< 24) {
		return "night";
	}

	return "midnight";
}

int main() {
	Time t1(12, 45);
	Time t2(16);
	cout << "time 1 = " << t1.GetHour() << ":" << t1.GetMinute()<<endl;
	cout << "time 2 = " << t2.GetHour() << ":" << t2.GetMinute()<<endl;

	t1.SetTime(18, 50);
	cout << "time 1 after change = " << t1.GetHour() << ":" << t1.GetMinute()<<endl;

	cout << "compare : " << t1.compare(t2)<<endl;
	cout << "time 2 of the day : " << t2.TimeOfDay()<<endl;
}

